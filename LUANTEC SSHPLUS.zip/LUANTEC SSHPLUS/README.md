# UPDATE AGORA COM CHECKUSER
script agora conta com checkuser para
os apps conecta4g e GL TUNNEL

# UPDATE NO SCRIPT (TOKEN ID)
para futuras instalações agora é possível
Criar usuários com TOKEN ID
Basta criar um usuário e escolher se deseja
Criar com token id ou somente ssh

# SSHPLUS

apt update -y && apt upgrade -y && wget https://raw.githubusercontent.com/VENHABRABO/SSHPLUS/main/Plus && chmod 777 Plus && ./Plus

# Acesso Root

wget https://raw.githubusercontent.com/VENHABRABO/SSHPLUS/main/senharoot.sh && chmod 777 senharoot.sh && ./senharoot.sh
# SSHPLUS
